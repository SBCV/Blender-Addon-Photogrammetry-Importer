from collections import namedtuple
Point = namedtuple('Point', ['coord', 'color', 'measurements', 'id', 'scalars']) 